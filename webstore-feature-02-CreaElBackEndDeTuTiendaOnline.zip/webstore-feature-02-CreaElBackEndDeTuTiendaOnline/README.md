# Webstore
Aprende a programar creando tu tienda online.

## 1 - Maqueta tu tienda online usando HTML, CSS y Javascript. | UtilAPIs
Video: https://youtu.be/yASvgVh8p5A
Código: https://github.com/utilapis/webstore/tree/feature/01-MaquetaTuTiendaOnline

## 2 - Crea el back-end de tu tienda online usando NodeJs y Express. | UtilAPIs
Video: https://youtu.be/w6X1PxtdH-M
Código: https://github.com/utilapis/webstore/tree/feature/02-CreaElBackEndDeTuTiendaOnline

